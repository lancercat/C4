Street signs from children of the Greek writting system.

Named after a haughty brat.

